import json
import re
import uuid
import boto3
import os
import base64
from datetime import datetime
from decimal import Decimal
from boto3.dynamodb.conditions import Key
import botocore.exceptions
from botocore.config import Config

# AWS Clients
dynamodb = boto3.resource('dynamodb', region_name='ap-south-1')
bedrock = boto3.client('bedrock-runtime', region_name='ap-south-1', config=Config(read_timeout=300))
bedrock_agent = boto3.client('bedrock-agent-runtime', region_name='ap-south-1')
s3 = boto3.client('s3', region_name='ap-south-1')
polly = boto3.client('polly', region_name='ap-south-1')
comprehend = boto3.client('comprehend', region_name='ap-south-1')
bedrock_us_east = boto3.client('bedrock-runtime', region_name='us-east-1', config=Config(read_timeout=300))
s3_us_east = boto3.client('s3', region_name='us-east-1')

# Constants / Env Vars
LEARNER_STATE_TABLE = "LearnerState"
SESSION_LOGS_TABLE = "SessionLogs"
KNOWLEDGE_GRAPH_TABLE = "KnowledgeGraph"
LEARNER_MASTERY_TABLE = "LearnerMastery"
LEITNER_BOX_TABLE = "LeitnerBox"
PRIMARY_MODEL_ID = os.environ.get("HAIKU_MODEL_ID", "apac.amazon.nova-pro-v1:0")
SONNET_MODEL_ID = os.environ.get("SONNET_MODEL_ID", "apac.amazon.nova-pro-v1:0")
FALLBACK_MODEL_ID = "apac.amazon.nova-pro-v1:0"
S3_CONTENT_BUCKET = os.environ.get("S3_CONTENT_BUCKET", "primelearn-content-cache-mumbai")
KNOWLEDGE_BASE_ID = os.environ.get("KNOWLEDGE_BASE_ID", "QCA57QK7UJ")


def call_llm(prompt, system_prompt=None, max_tokens=2500, model_id=None):
    """Call Bedrock LLM using Converse API. Tries primary model, falls back to Nova Pro."""
    models_to_try = [model_id or PRIMARY_MODEL_ID]
    if FALLBACK_MODEL_ID not in models_to_try:
        models_to_try.append(FALLBACK_MODEL_ID)
    for mid in models_to_try:
        try:
            params = {
                "modelId": mid,
                "messages": [{"role": "user", "content": [{"text": prompt}]}],
                "inferenceConfig": {"maxTokens": max_tokens}
            }
            if system_prompt:
                params["system"] = [{"text": system_prompt}]
            response = bedrock.converse(**params)
            return response['output']['message']['content'][0]['text'], mid
        except Exception as e:
            print(f"LLM error (model={mid}): {e}")
            if mid == models_to_try[-1]:
                raise
    return None, None

CORS_HEADERS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
}

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)

def respond(status_code, body):
    return {
        "statusCode": status_code,
        "headers": CORS_HEADERS,
        "body": json.dumps(body, cls=DecimalEncoder)
    }

def get_body(event):
    if not event.get('body'):
        return {}
    return json.loads(event['body']) if isinstance(event['body'], str) else event['body']

def safe_parse_json_object(text):
    """Safely extract and parse a JSON object from LLM response text."""
    cleaned = text.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    match = re.search(r'\{[\s\S]*\}', cleaned)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    return None


# ─── Amazon Bedrock Knowledge Bases (RAG) ───────────────────────────────────
def retrieve_from_knowledge_base(concept_name, max_results=3):
    """
    Retrieve relevant context from Bedrock Knowledge Base (RAG).
    Used to ground episode content in curated syllabus/reference material.
    """
    try:
        response = bedrock_agent.retrieve(
            knowledgeBaseId=KNOWLEDGE_BASE_ID,
            retrievalQuery={'text': concept_name},
            retrievalConfiguration={
                'vectorSearchConfiguration': {
                    'numberOfResults': max_results
                }
            }
        )
        results = response.get('retrievalResults', [])
        context_chunks = []
        for r in results:
            text = r.get('content', {}).get('text', '')
            if text:
                context_chunks.append(text[:500])  # Limit each chunk
        return "\n---\n".join(context_chunks)
    except Exception as e:
        print(f"Knowledge Base retrieval error: {e}")
        return ""


# ─── Amazon Polly (Text-to-Speech) ──────────────────────────────────────────
def generate_narration(text_content, episode_id, language='en'):
    """
    Generate voice narration for Visual Story episodes using Amazon Polly.
    Returns S3 URL of the audio file.
    """
    # Strip HTML tags for narration
    clean_text = re.sub(r'<[^>]+>', ' ', text_content)
    clean_text = re.sub(r'\s+', ' ', clean_text).strip()

    # Limit to Polly's max (3000 chars for standard, use SSML for longer)
    if len(clean_text) > 2800:
        clean_text = clean_text[:2800] + "..."

    # Select voice based on language
    voice_id = 'Aditi' if language == 'hi' else 'Kajal'  # Kajal = Indian English, Aditi = Hindi
    engine = 'neural'

    try:
        polly_response = polly.synthesize_speech(
            Text=clean_text,
            OutputFormat='mp3',
            VoiceId=voice_id,
            Engine=engine
        )

        # Save to S3
        audio_key = f"narrations/{episode_id}.mp3"
        audio_stream = polly_response['AudioStream'].read()

        s3.put_object(
            Bucket=S3_CONTENT_BUCKET,
            Key=audio_key,
            Body=audio_stream,
            ContentType='audio/mpeg'
        )

        # Generate presigned URL (valid 1 hour)
        audio_url = s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': S3_CONTENT_BUCKET, 'Key': audio_key},
            ExpiresIn=3600
        )
        return audio_url
    except Exception as e:
        print(f"Polly narration error: {e}")
        return None


# ─── Amazon Nova Canvas (AI Image Generation) ────────────────────────────
NOVA_CANVAS_MODEL_ID = "amazon.nova-canvas-v1:0"


def generate_concept_image(concept_name, section_title, section_context, style="educational"):
    """
    Generate an AI illustration for a concept section using Amazon Nova Canvas.
    Returns presigned S3 URL of the generated image, or None on failure.
    """
    style_prompts = {
        "educational": "Clean, modern educational infographic style with flat design, vibrant gradients, dark navy background, glowing accents, professional typography",
        "technical": "Technical blueprint style with circuit-board patterns, neon blue and gold highlights, dark background, isometric 3D elements",
        "conceptual": "Abstract conceptual art, flowing shapes representing data and knowledge, deep purple and gold color palette, ethereal lighting",
        "architectural": "3D architectural diagram, clean geometric shapes, glass and metal materials, ambient occlusion, soft studio lighting",
    }

    style_desc = style_prompts.get(style, style_prompts["educational"])

    prompt = (
        f"Educational illustration for '{section_title}' about {concept_name}. "
        f"{section_context}. "
        f"{style_desc}. "
        "No text or words in the image. High quality, 4K detail."
    )[:512]

    try:
        body = json.dumps({
            "taskType": "TEXT_IMAGE",
            "textToImageParams": {"text": prompt},
            "imageGenerationConfig": {
                "numberOfImages": 1,
                "height": 720,
                "width": 1280,
                "cfgScale": 8.0,
                "seed": hash(concept_name + section_title) % 2147483647
            }
        })

        response = bedrock_us_east.invoke_model(
            body=body,
            modelId=NOVA_CANVAS_MODEL_ID,
            accept="application/json",
            contentType="application/json"
        )

        response_body = json.loads(response["body"].read())
        if response_body.get("error"):
            print(f"Nova Canvas error: {response_body['error']}")
            return None

        base64_image = response_body.get("images", [None])[0]
        if not base64_image:
            return None

        image_bytes = base64.b64decode(base64_image)

        # Upload to S3
        image_key = f"images/{concept_name.replace(' ', '-').lower()}/{uuid.uuid4()}.png"
        s3.put_object(
            Bucket=S3_CONTENT_BUCKET,
            Key=image_key,
            Body=image_bytes,
            ContentType='image/png'
        )

        image_url = s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': S3_CONTENT_BUCKET, 'Key': image_key},
            ExpiresIn=3600
        )
        return image_url

    except Exception as e:
        print(f"Nova Canvas image generation error: {e}")
        return None


# ─── Amazon Comprehend (NLP Analysis) ─────────────────────────────────────

def analyze_learner_input(text, language='en'):
    """
    Use Amazon Comprehend to analyze learner input for sentiment, key phrases,
    and entities. Used to adapt content difficulty and detect confusion/frustration.
    """
    result = {"sentiment": "NEUTRAL", "key_phrases": [], "entities": [], "confusion_score": 0}

    try:
        lang_code = 'en' if language == 'en' else 'hi'

        # Sentiment analysis
        sentiment_resp = comprehend.detect_sentiment(Text=text[:5000], LanguageCode=lang_code)
        result["sentiment"] = sentiment_resp.get("Sentiment", "NEUTRAL")
        scores = sentiment_resp.get("SentimentScore", {})
        # Confusion heuristic: high mixed + negative signals confusion
        result["confusion_score"] = round(
            scores.get("Mixed", 0) * 0.5 + scores.get("Negative", 0) * 0.3, 3
        )

        # Key phrases
        phrases_resp = comprehend.detect_key_phrases(Text=text[:5000], LanguageCode=lang_code)
        result["key_phrases"] = [
            p["Text"] for p in phrases_resp.get("KeyPhrases", [])[:10]
        ]

        # Entity detection
        entities_resp = comprehend.detect_entities(Text=text[:5000], LanguageCode=lang_code)
        result["entities"] = [
            {"text": e["Text"], "type": e["Type"]}
            for e in entities_resp.get("Entities", [])[:10]
        ]
    except Exception as e:
        print(f"Comprehend analysis error: {e}")

    return result


# ─── Bedrock Guardrails (Content Safety) ──────────────────────────────────
GUARDRAIL_ID = os.environ.get("GUARDRAIL_ID", "")
GUARDRAIL_VERSION = os.environ.get("GUARDRAIL_VERSION", "DRAFT")


def apply_guardrail(text):
    """
    Apply Bedrock Guardrails to filter harmful/inappropriate content.
    Returns (is_safe, filtered_text).
    """
    if not GUARDRAIL_ID:
        return True, text

    try:
        response = bedrock.apply_guardrail(
            guardrailIdentifier=GUARDRAIL_ID,
            guardrailVersion=GUARDRAIL_VERSION,
            source="OUTPUT",
            content=[{"text": {"text": text[:10000]}}]
        )
        action = response.get("action", "NONE")
        if action == "GUARDRAIL_INTERVENED":
            outputs = response.get("outputs", [])
            filtered = outputs[0]["text"] if outputs else "Content filtered for safety."
            return False, filtered
        return True, text
    except Exception as e:
        print(f"Guardrail error: {e}")
        return True, text


def determine_format(concept, learner=None, is_revision=False, time_available=30):
    """Select episode format based on concept type and learner profile."""
    if is_revision or time_available < 10:
        return 'Quick Byte'

    c_type = concept.get('type', concept.get('concept_type', '')).lower()
    requires_hands_on = concept.get('requires_hands_on', False)
    depth = concept.get('depth', concept.get('complexity_level', '')).lower()
    can_code = True
    if learner:
        can_code = learner.get('can_code', True)

    if requires_hands_on and can_code:
        return 'Code Lab'

    if c_type in ['architectural', 'visual', 'networking', 'cloud', 'conceptual']:
        return 'Visual Story'

    if not can_code and c_type != 'theoretical':
        return 'Visual Story'

    if c_type == 'applied':
        return 'Case Study'

    if c_type == 'theoretical' and depth in ['intermediate', 'advanced']:
        return 'Concept X-Ray'

    return 'Visual Story'


def handle_get_episode(event):
    path_parameters = event.get('pathParameters') or {}
    episode_id = path_parameters.get('episode_id')
    query_params = event.get('queryStringParameters') or {}
    learner_id = query_params.get('learner_id')
    concept_id = query_params.get('concept_id', episode_id)

    if not episode_id:
        return respond(400, {"error": "episode_id is required"})

    # Read learner profile FIRST (needed for personalized cache key)
    learner = {}
    if learner_id:
        state_table = dynamodb.Table(LEARNER_STATE_TABLE)
        learner_resp = state_table.get_item(Key={'learner_id': learner_id})
        learner = learner_resp.get('Item', {})

    ability_score = float(learner.get('ability_score', 0.5))
    language = learner.get('language', 'en')

    # Ability bracket for cache: beginner(0-0.3), intermediate(0.3-0.7), advanced(0.7-1.0)
    ability_bracket = 'beginner' if ability_score < 0.3 else ('intermediate' if ability_score < 0.7 else 'advanced')

    # Cache key includes concept + ability level + language (personalized)
    cache_key = f"episodes/{episode_id}/{ability_bracket}_{language}.json"
    try:
        s3_response = s3.get_object(Bucket=S3_CONTENT_BUCKET, Key=cache_key)
        cached_episode = json.loads(s3_response['Body'].read().decode('utf-8'))
        return respond(200, cached_episode)
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] != 'NoSuchKey':
            print(f"S3 error: {e}")

    # Read concept metadata
    kg_table = dynamodb.Table(KNOWLEDGE_GRAPH_TABLE)
    concept_resp = kg_table.get_item(Key={'concept_id': concept_id})
    concept = concept_resp.get('Item', {})
    concept_name = concept.get('label', concept.get('name', concept.get('concept_name', concept_id)))

    is_revision = query_params.get('is_revision', 'false').lower() == 'true'
    time_available = int(query_params.get('time_available', 30))

    # Select format
    format_type = determine_format(concept, learner, is_revision=is_revision, time_available=time_available)

    # ─── Bedrock Knowledge Bases RAG: Retrieve grounding context ─────────
    rag_context = retrieve_from_knowledge_base(concept_name)
    rag_instruction = ""
    if rag_context:
        rag_instruction = (
            f"\n\nUse the following reference material to ground your content:\n"
            f"---\n{rag_context}\n---\n"
            "Incorporate key points from this material into your episode content."
        )

    # Build prompt
    lang_instruction = ""
    if language == 'hi':
        lang_instruction = " Respond in Hinglish (Hindi-English code-mixed). Keep technical terms in English."

    context_str = ""
    if format_type == 'Case Study':
        context_str = " Include a real-world Indian company context (e.g., Zomato, UPI, Flipkart, IRCTC, Paytm, Aadhaar)."

    # ─── Sonnet/Pro for Code Lab (complex reasoning), Haiku/Nova for others ──
    if format_type == 'Code Lab':
        model_id = SONNET_MODEL_ID
        code_instruction = (
            " Include 'starter_code' (Python boilerplate for the learner to start with) "
            "and 'solution_code' (complete correct solution) as top-level keys in the JSON."
        )
    else:
        model_id = PRIMARY_MODEL_ID
        code_instruction = ""

    # ─── Ability-adaptive complexity ─────────────────────────────────────
    complexity_instruction = ""
    if ability_score >= 0.7:
        complexity_instruction = (
            " Target ADVANCED level. Use industry jargon, discuss edge cases, trade-offs, "
            "internal implementations, and performance considerations. "
            "Reference real-world systems (AWS internals, Linux kernel, distributed systems). "
            "Assume strong fundamentals."
        )
    elif ability_score >= 0.3:
        complexity_instruction = (
            " Target INTERMEDIATE level. Explain the 'why' behind concepts, not just the 'what'. "
            "Include comparisons with alternatives, practical use cases, and common pitfalls. "
            "Build on assumed basic knowledge."
        )
    else:
        complexity_instruction = (
            " Target BEGINNER level. Use clear analogies from everyday life. "
            "Build intuition before formalism. Focus on mental models over syntax."
        )

    # ─── Format-specific prompt instructions ──────────────────────────────
    format_instructions = ""
    if format_type == 'Visual Story':
        format_instructions = (
            "\n\nFor this Visual Story format, structure the content as rich VISUAL SECTIONS. "
            "Return an additional key 'sections' (array of objects), each with:\n"
            "- 'title': section heading\n"
            "- 'content': Rich HTML explanation with <h3>, <p>, <ul>, <code>, <blockquote> tags. "
            "Include real-world examples, analogies, and key insights.\n"
            "- 'image_prompt': A vivid 1-2 sentence description of an educational illustration for THIS section. "
            "Describe what the image should show visually (diagrams, architecture, data flow, etc). "
            "AI will generate a unique illustration from this prompt.\n"
            "Generate 4-6 sections. Make content deep and insightful, not surface-level."
        )
    elif format_type == 'Concept X-Ray':
        format_instructions = (
            "\n\nFor this X-Ray format, provide layered drill-down from surface to internals. "
            "Return an additional key 'layers' (array of objects), each with:\n"
            "- 'title': layer name (e.g., 'What It Does', 'How It Works', 'Under the Hood', 'Edge Cases & Gotchas')\n"
            "- 'content': Rich HTML explanation with code examples where relevant\n"
            "- 'image_prompt': description of an illustration showing this layer's concept\n"
            "Provide 3-5 layers, each progressively deeper. Last layer should be expert-level."
        )
    elif format_type == 'Case Study':
        format_instructions = (
            "\n\nFor this Case Study format, include:\n"
            "- 'scenario_context': detailed description of the real-world scenario (company, problem, constraints)\n"
            "- 'what_if_scenarios': array of 3-4 objects with 'question' and 'answer' for What-If analysis. "
            "Make these challenging: 'What if traffic spikes 100x?', 'What if the primary DB fails?'\n"
            "- 'image_prompt': description of an architectural diagram for this system\n"
            "- 'key_decisions': array of critical design decisions made in this system"
        )
    elif format_type == 'Quick Byte':
        format_instructions = (
            "\n\nFor Quick Byte, keep it very concise (3-5 min read). Include:\n"
            "- 'summary': one-line key takeaway\n"
            "- 'image_prompt': description of a single key visual\n"
            "- Exactly 2 activities (mcq type, make them tricky)"
        )

    prompt = (
        f"Generate a learning episode about '{concept_name}'. "
        f"The format is '{format_type}'. "
        f"The learner has an ability score of {ability_score:.2f} (0.0=beginner, 1.0=expert). "
        f"{complexity_instruction}{lang_instruction}{context_str}{code_instruction}"
        f"{rag_instruction}{format_instructions}\n\n"
        "IMPORTANT: Write like a senior engineer teaching a mentee, not like a textbook. "
        "Use practical examples, war stories, and real system references. "
        "Avoid generic filler like 'In today's world' or 'This is important because'. "
        "Get straight to the substance.\n\n"
        "Return ONLY a JSON object with these keys:\n"
        "- 'title': episode title (creative, specific - NOT generic like 'Introduction to X')\n"
        "- 'content': the main learning content as rich HTML\n"
        "- 'activities': array of 2-3 objects with 'type' (mcq/coding/fill_blank), 'question', 'options' (array of 4 strings for mcq), 'correct' (index or string). Make questions actually challenging.\n"
        "Do not include any explanation outside the JSON."
    )

    episode_data = None
    used_model = None
    try:
        content_text, used_model = call_llm(prompt, max_tokens=2500, model_id=model_id)
        if content_text:
            episode_data = safe_parse_json_object(content_text)
    except Exception as e:
        print(f"Bedrock error (model={model_id}): {e}")

    if not episode_data:
        episode_data = {
            "title": f"Episode: {concept_name}",
            "content": f"<h2>{concept_name}</h2><p>This episode covers the fundamentals of {concept_name}. Content generation is temporarily unavailable.</p>",
            "activities": []
        }

    episode_data['episode_id'] = episode_id
    episode_data['concept_id'] = concept_id
    episode_data['format'] = format_type
    episode_data['model_used'] = (used_model or 'fallback').split('.')[-1].split('-')[0] if used_model else 'fallback'
    episode_data['rag_grounded'] = bool(rag_context)

    # ─── Bedrock Guardrails: Filter generated content ─────────────────────
    is_safe, filtered_content = apply_guardrail(episode_data.get('content', ''))
    if not is_safe:
        episode_data['content'] = filtered_content
        episode_data['guardrail_filtered'] = True
    episode_data['guardrail_applied'] = bool(GUARDRAIL_ID)

    # ─── Amazon Nova Canvas: Generate AI illustrations for sections ───────
    # Replace Mermaid diagrams with actual AI-generated educational images
    sections_key = None
    if format_type == 'Visual Story' and episode_data.get('sections'):
        sections_key = 'sections'
    elif format_type == 'Concept X-Ray' and episode_data.get('layers'):
        sections_key = 'layers'

    if sections_key:
        # Determine visual style based on concept type
        c_type = concept.get('type', '').lower()
        if c_type in ['architectural', 'cloud', 'networking']:
            img_style = 'architectural'
        elif c_type in ['applied', 'theoretical']:
            img_style = 'technical'
        else:
            img_style = 'educational'

        for section in episode_data[sections_key][:2]:  # Limit to 2 images to stay within API Gateway 29s timeout
            image_prompt = section.get('image_prompt', section.get('title', ''))
            if image_prompt:
                image_url = generate_concept_image(
                    concept_name,
                    section.get('title', 'Concept'),
                    image_prompt,
                    style=img_style
                )
                if image_url:
                    section['image_url'] = image_url
                    section.pop('diagram', None)  # Remove old Mermaid diagram

    # Also generate a single image for Case Study and Quick Byte
    if format_type in ('Case Study', 'Quick Byte'):
        img_prompt = episode_data.get('image_prompt', f"Visual diagram of {concept_name}")
        hero_image = generate_concept_image(concept_name, concept_name, img_prompt, style='technical')
        if hero_image:
            episode_data['hero_image_url'] = hero_image

    # ─── Amazon Polly: Generate narration for Visual Story episodes ──────
    if format_type == 'Visual Story' and episode_data.get('content'):
        audio_url = generate_narration(episode_data['content'], episode_id, language)
        if audio_url:
            episode_data['narration_url'] = audio_url

    # Cache to S3
    try:
        s3.put_object(
            Bucket=S3_CONTENT_BUCKET,
            Key=cache_key,
            Body=json.dumps(episode_data).encode('utf-8'),
            ContentType='application/json'
        )
    except Exception as e:
        print(f"S3 cache write error: {e}")

    return respond(200, episode_data)


def handle_post_progress(event):
    path_parameters = event.get('pathParameters') or {}
    episode_id = path_parameters.get('episode_id')
    body = get_body(event)

    learner_id = body.get('learner_id')
    concept_id = body.get('concept_id', episode_id)
    completion_rate = float(body.get('completion_rate', 0.0))
    time_spent_seconds = int(body.get('time_spent_seconds', 0))

    if not all([episode_id, learner_id]):
        return respond(400, {"error": "episode_id and learner_id are required"})

    table = dynamodb.Table(SESSION_LOGS_TABLE)
    timestamp = datetime.utcnow().isoformat()
    action = "EPISODE_COMPLETE" if completion_rate >= 1.0 else "PROGRESS_UPDATE"

    table.put_item(Item={
        'learner_id': learner_id,
        'timestamp': timestamp,
        'episode_id': episode_id,
        'concept_id': concept_id,
        'action': action,
        'completion_rate': Decimal(str(completion_rate)),
        'time_spent_seconds': time_spent_seconds
    })

    if completion_rate >= 1.0:
        state_table = dynamodb.Table(LEARNER_STATE_TABLE)
        try:
            state_table.update_item(
                Key={'learner_id': learner_id},
                UpdateExpression="SET last_active = :la, streak = if_not_exists(streak, :zero) + :inc",
                ExpressionAttributeValues={
                    ":la": timestamp,
                    ":zero": 0,
                    ":inc": 1
                }
            )
        except Exception as e:
            print(f"Streak update error: {e}")

    return respond(200, {
        "message": "Progress recorded",
        "episode_id": episode_id,
        "completion_rate": completion_rate,
        "action": action
    })


def handle_get_dashboard(event):
    path_parameters = event.get('pathParameters') or {}
    learner_id = path_parameters.get('learner_id')

    if not learner_id:
        return respond(400, {"error": "learner_id is required"})

    # 1. Read LearnerState
    state_table = dynamodb.Table(LEARNER_STATE_TABLE)
    profile = state_table.get_item(Key={'learner_id': learner_id}).get('Item', {})

    # 2. Read LearnerMastery
    mastery_table = dynamodb.Table(LEARNER_MASTERY_TABLE)
    mastery_resp = mastery_table.query(KeyConditionExpression=Key('learner_id').eq(learner_id))
    mastery_items = mastery_resp.get('Items', [])

    total_mastered = sum(1 for m in mastery_items if float(m.get('p_known', 0)) >= 0.85)

    # Build skill radar data
    skill_groups = {}
    for m in mastery_items:
        concept_id = m.get('concept_id', '')
        p_known = float(m.get('p_known', 0))
        category = concept_id.split('-')[0].upper() if '-' in concept_id else concept_id[:3].upper()
        if category not in skill_groups:
            skill_groups[category] = []
        skill_groups[category].append(p_known)

    radar_data = []
    for subject, scores in skill_groups.items():
        avg = sum(scores) / len(scores) if scores else 0
        radar_data.append({"subject": subject[:6], "A": round(avg * 150, 1), "fullMark": 150})

    if not radar_data:
        radar_data = [
            {"subject": "DSA", "A": 30, "fullMark": 150},
            {"subject": "WEB", "A": 20, "fullMark": 150},
            {"subject": "DB", "A": 15, "fullMark": 150},
            {"subject": "CLOUD", "A": 10, "fullMark": 150},
            {"subject": "SYS", "A": 5, "fullMark": 150},
        ]

    # 3. Read LeitnerBox
    leitner_table = dynamodb.Table(LEITNER_BOX_TABLE)
    leitner_resp = leitner_table.query(KeyConditionExpression=Key('learner_id').eq(learner_id))
    leitner_items = leitner_resp.get('Items', [])

    now = datetime.utcnow().isoformat()
    due_now = sum(1 for item in leitner_items if item.get('next_review_date', now) <= now)

    box_counts = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    for item in leitner_items:
        box = int(item.get('box', item.get('box_number', 1)))
        box_counts[box] = box_counts.get(box, 0) + 1

    # 4. Read recent SessionLogs
    logs_table = dynamodb.Table(SESSION_LOGS_TABLE)
    logs_resp = logs_table.query(
        KeyConditionExpression=Key('learner_id').eq(learner_id),
        ScanIndexForward=False,
        Limit=10
    )
    recent_activity = logs_resp.get('Items', [])

    # 5. BKT data
    bkt_data = []
    for m in mastery_items[:10]:
        bkt_data.append({
            "concept_id": m.get('concept_id'),
            "p_known": float(m.get('p_known', 0)),
            "status": m.get('status', 'in_progress')
        })

    total_seconds = sum(int(log.get('time_spent_seconds', 0)) for log in recent_activity)

    return respond(200, {
        "learner_id": learner_id,
        "profile": profile,
        "mastery": {
            "items": mastery_items,
            "total_mastered": total_mastered,
            "total_concepts": len(mastery_items)
        },
        "radar_data": radar_data,
        "bkt_data": bkt_data,
        "leitner": {
            "items": leitner_items,
            "due_now": due_now,
            "box_counts": box_counts
        },
        "recent_activity": recent_activity,
        "stats": {
            "streak": int(profile.get('streak', 0)),
            "total_hours": round(total_seconds / 3600, 1) if total_seconds > 0 else float(profile.get('total_hours', 0))
        }
    })


def handle_get_constellation(event):
    """Return the PERSONALIZED knowledge graph for this learner as nodes + links."""
    query_params = event.get('queryStringParameters') or {}
    learner_id = query_params.get('learner_id')

    if not learner_id:
        return respond(400, {"error": "learner_id is required"})

    # 1. Get THIS learner's mastery entries (personalized concept list)
    mastery_table = dynamodb.Table(LEARNER_MASTERY_TABLE)
    mastery_resp = mastery_table.query(KeyConditionExpression=Key('learner_id').eq(learner_id))
    mastery_items = mastery_resp.get('Items', [])
    mastery_map = {m['concept_id']: m for m in mastery_items}

    if not mastery_items:
        return respond(200, {"learner_id": learner_id, "nodes": [], "links": [], "message": "No concepts yet. Complete onboarding first."})

    # 2. Fetch concept details from KnowledgeGraph only for this learner's concepts
    kg_table = dynamodb.Table(KNOWLEDGE_GRAPH_TABLE)
    concept_ids = list(mastery_map.keys())

    nodes = []
    links = []
    concept_details = {}

    for cid in concept_ids:
        try:
            kg_resp = kg_table.get_item(Key={'concept_id': cid})
            concept = kg_resp.get('Item', {})
            if concept:
                concept_details[cid] = concept
        except Exception:
            pass

    # 3. Build nodes with mastery state + stored x/y positions
    for i, cid in enumerate(concept_ids):
        concept = concept_details.get(cid, {})
        mastery_entry = mastery_map[cid]
        p_known = float(mastery_entry.get('p_known', 0))
        status = mastery_entry.get('status', 'locked')

        if p_known >= 0.85:
            state = 'mastered'
        elif status == 'unlocked' or p_known > 0:
            state = 'active'
        else:
            state = 'locked'

        # Use stored x/y from KnowledgeGraph, fallback to calculated grid
        row = i // 4
        col = i % 4
        x = int(concept.get('x', 15 + col * 22))
        y = int(concept.get('y', 15 + row * 25))

        nodes.append({
            "id": cid,
            "concept_id": cid,
            "label": concept.get('label', concept.get('name', cid.replace('-', ' ').title())),
            "x": x,
            "y": y,
            "state": state,
            "mastery": round(p_known, 4),
            "type": concept.get('type', 'general'),
            "level": concept.get('level', 'beginner')
        })

        prereqs = concept.get('prerequisites', [])
        if isinstance(prereqs, list):
            for prereq in prereqs:
                if prereq in mastery_map:
                    links.append({"source": prereq, "target": cid})

    return respond(200, {
        "learner_id": learner_id,
        "nodes": nodes,
        "links": links
    })


# ─── Amazon Nova Reel (Video Generation) ─────────────────────────────────
VIDEO_OUTPUT_BUCKET = "primelearn-content-cache"


def generate_video_storyboard(concept_name, user_prompt, concept_data=None):
    """
    Use LLM to generate a full educational video storyboard.
    Returns either a rich automated prompt (4000 chars) or manual scene descriptions.
    """
    concept_context = ""
    if concept_data:
        concept_context = (
            f"Concept: {concept_data.get('label', concept_name)}. "
            f"Type: {concept_data.get('type', 'general')}. "
            f"Level: {concept_data.get('level', 'beginner')}."
        )

    prompt = (
        f"You are a cinematic educational video script writer. "
        f"A student wants to learn about '{concept_name}'. {concept_context}\n"
        f"Their request: \"{user_prompt}\"\n\n"
        "Write a detailed, vivid video script for an AI video generator (Amazon Nova Reel). "
        "The video should be an educational explainer that covers the topic comprehensively.\n\n"
        "Structure it as a flowing narrative that describes visual scenes:\n"
        "- Opening: Hook scene that introduces the topic visually\n"
        "- Middle (2-3 scenes): Core concepts explained through animations, diagrams, visual metaphors\n"
        "- Closing: Summary scene that ties everything together\n\n"
        "Describe what the VIEWER SEES: camera movements, colors, animations, 3D objects, "
        "text overlays, transitions between scenes. Make it feel like a Kurzgesagt or 3Blue1Brown video.\n\n"
        "Write it as ONE continuous flowing description (not numbered scenes). "
        "Be extremely vivid and visual. Max 3500 characters.\n"
        "Return ONLY the script text, nothing else."
    )

    try:
        result, _ = call_llm(prompt, max_tokens=1200)
        if result:
            return result.strip().strip('"')[:3900]
    except Exception as e:
        print(f"Storyboard generation error: {e}")

    # Fallback
    return (
        f"An educational animated documentary about {concept_name}. "
        f"Opening: Camera zooms into a dark space where glowing particles form the title '{concept_name}'. "
        f"The particles rearrange into a 3D diagram. "
        f"Middle: Smooth animations show the core concepts with colorful visualizations, "
        f"flowing data streams, and expanding diagrams. Text overlays explain key points. "
        f"Each concept builds on the previous one with seamless transitions. "
        f"Closing: All elements come together in a final comprehensive view, "
        f"camera pulls back to show the complete picture. {user_prompt}"
    )[:3900]


def generate_narration_script(concept_name, user_prompt, concept_data=None):
    """Generate a voiceover narration script to accompany the video."""
    concept_context = ""
    if concept_data:
        concept_context = f"The concept is: {concept_data.get('label', concept_name)} ({concept_data.get('type', 'general')}, {concept_data.get('level', 'beginner')} level)."

    prompt = (
        f"Write a clear, engaging narration script for an educational video about '{concept_name}'. "
        f"{concept_context}\n"
        f"Student's request: \"{user_prompt}\"\n\n"
        "The narration should:\n"
        "- Be conversational and easy to follow\n"
        "- Explain the concept from basics to deeper understanding\n"
        "- Take about 30-45 seconds to read aloud\n"
        "- Use simple analogies where helpful\n\n"
        "Return ONLY the narration text. No stage directions or formatting. Max 2500 characters."
    )

    try:
        result, _ = call_llm(prompt, max_tokens=800)
        if result:
            return result.strip()[:2800]
    except Exception as e:
        print(f"Narration script generation error: {e}")
    return None


def handle_generate_video(event):
    """
    POST /video/generate
    Generate a full educational video using Nova Reel v1:1 (up to 2 min).
    Uses MULTI_SHOT_AUTOMATED for AI-directed scene composition.
    Body: { "learner_id": "...", "concept_id": "...", "prompt": "...", "duration": 24 }
    """
    body = get_body(event)
    learner_id = body.get('learner_id')
    concept_id = body.get('concept_id')
    user_prompt = body.get('prompt')
    requested_duration = int(body.get('duration', 24))

    if not all([learner_id, concept_id, user_prompt]):
        return respond(400, {"error": "learner_id, concept_id, and prompt are required"})

    # Clamp duration to valid range (must be multiple of 6, min 12 for multi-shot, max 120)
    duration = max(12, min(120, requested_duration))
    duration = (duration // 6) * 6  # Round down to multiple of 6

    # Fetch concept metadata
    concept_data = {}
    try:
        kg_table = dynamodb.Table(KNOWLEDGE_GRAPH_TABLE)
        concept_resp = kg_table.get_item(Key={'concept_id': concept_id})
        concept_data = concept_resp.get('Item', {})
    except Exception:
        pass
    concept_name = concept_data.get('label', concept_id.replace('-', ' ').title())

    # Generate AI storyboard (rich 4000-char prompt for automated multi-shot)
    video_script = generate_video_storyboard(concept_name, user_prompt, concept_data)

    # Generate narration script + Polly audio
    narration_text = generate_narration_script(concept_name, user_prompt, concept_data)
    narration_url = None
    if narration_text:
        narration_key = f"video-narrations/{concept_id}/{uuid.uuid4()}.mp3"
        try:
            # Get learner language
            learner_lang = 'en'
            if learner_id:
                state_table = dynamodb.Table(LEARNER_STATE_TABLE)
                lr = state_table.get_item(Key={'learner_id': learner_id}).get('Item', {})
                learner_lang = lr.get('language', 'en')

            voice_id = 'Aditi' if learner_lang == 'hi' else 'Kajal'
            polly_resp = polly.synthesize_speech(
                Text=narration_text[:2800],
                OutputFormat='mp3',
                VoiceId=voice_id,
                Engine='neural'
            )
            s3.put_object(
                Bucket=S3_CONTENT_BUCKET,
                Key=narration_key,
                Body=polly_resp['AudioStream'].read(),
                ContentType='audio/mpeg'
            )
            narration_url = s3.generate_presigned_url(
                'get_object',
                Params={'Bucket': S3_CONTENT_BUCKET, 'Key': narration_key},
                ExpiresIn=3600
            )
        except Exception as e:
            print(f"Narration generation error: {e}")

    job_id = str(uuid.uuid4())
    s3_output_uri = f"s3://{VIDEO_OUTPUT_BUCKET}/videos/{concept_id}/{job_id}/"

    try:
        response = bedrock_us_east.start_async_invoke(
            modelId="amazon.nova-reel-v1:1",
            modelInput={
                "taskType": "MULTI_SHOT_AUTOMATED",
                "multiShotAutomatedParams": {
                    "text": video_script
                },
                "videoGenerationConfig": {
                    "durationSeconds": duration,
                    "fps": 24,
                    "dimension": "1280x720"
                }
            },
            outputDataConfig={
                "s3OutputDataConfig": {
                    "s3Uri": s3_output_uri
                }
            }
        )

        invocation_arn = response.get('invocationArn', '')

        # Store narration URL in S3 metadata for retrieval on status check
        if narration_url:
            try:
                s3_us_east.put_object(
                    Bucket=VIDEO_OUTPUT_BUCKET,
                    Key=f"videos/{concept_id}/{job_id}/narration_url.txt",
                    Body=narration_url,
                    ContentType='text/plain'
                )
            except Exception:
                pass

        return respond(200, {
            "invocation_arn": invocation_arn,
            "status": "InProgress",
            "s3_output_uri": s3_output_uri,
            "concept_id": concept_id,
            "learner_id": learner_id,
            "video_script": video_script[:500] + "...",
            "narration_url": narration_url,
            "narration_text": narration_text,
            "duration_seconds": duration
        })
    except Exception as e:
        print(f"Nova Reel v1:1 start_async_invoke error: {e}")
        # Fallback to v1:0 single-shot 6s if v1:1 fails
        try:
            fallback_prompt = video_script[:512]
            response = bedrock_us_east.start_async_invoke(
                modelId="amazon.nova-reel-v1:0",
                modelInput={
                    "taskType": "TEXT_VIDEO",
                    "textToVideoParams": {"text": fallback_prompt},
                    "videoGenerationConfig": {
                        "durationSeconds": 6,
                        "fps": 24,
                        "dimension": "1280x720"
                    }
                },
                outputDataConfig={
                    "s3OutputDataConfig": {"s3Uri": s3_output_uri}
                }
            )
            return respond(200, {
                "invocation_arn": response.get('invocationArn', ''),
                "status": "InProgress",
                "s3_output_uri": s3_output_uri,
                "concept_id": concept_id,
                "learner_id": learner_id,
                "video_script": fallback_prompt,
                "narration_url": narration_url,
                "narration_text": narration_text,
                "duration_seconds": 6,
                "fallback": True
            })
        except Exception as e2:
            print(f"Nova Reel v1:0 fallback error: {e2}")
            return respond(500, {"error": "Failed to start video generation", "details": str(e)})


def handle_video_status(event):
    """
    GET /video/status?invocation_arn=...
    Check the status of a Nova Reel video generation job.
    If completed, return a presigned URL for the output video.
    """
    query_params = event.get('queryStringParameters') or {}
    invocation_arn = query_params.get('invocation_arn')

    if not invocation_arn:
        return respond(400, {"error": "invocation_arn query parameter is required"})

    try:
        response = bedrock_us_east.get_async_invoke(
            invocationArn=invocation_arn
        )

        status = response.get('status', 'Unknown')
        result = {"status": status}

        if status == "Completed":
            s3_uri = response.get('outputDataConfig', {}).get('s3OutputDataConfig', {}).get('s3Uri', '')
            if s3_uri:
                # Parse the S3 URI to get bucket and key for the output video
                # s3_uri format: s3://bucket/prefix/
                # The video file is at {s3Uri}/output.mp4
                s3_parts = s3_uri.replace("s3://", "").split("/", 1)
                bucket = s3_parts[0]
                prefix = s3_parts[1] if len(s3_parts) > 1 else ""
                video_key = prefix.rstrip("/") + "/output.mp4"

                video_url = s3_us_east.generate_presigned_url(
                    'get_object',
                    Params={'Bucket': bucket, 'Key': video_key},
                    ExpiresIn=3600
                )
                result["video_url"] = video_url
                result["s3_uri"] = s3_uri

        elif status == "Failed":
            failure_message = response.get('failureMessage', 'Unknown error')
            result["failure_message"] = failure_message

        return respond(200, result)
    except Exception as e:
        print(f"Nova Reel get_async_invoke error: {e}")
        return respond(500, {"error": "Failed to get video status", "details": str(e)})


def lambda_handler(event, context):
    http_method = event.get('httpMethod') or event.get('requestContext', {}).get('http', {}).get('method', '')
    if http_method == 'OPTIONS':
        return respond(200, {})

    try:
        path = event.get('resource') or event.get('rawPath', '')

        if http_method == 'GET' and '/episodes/' in path and not path.endswith('/progress'):
            return handle_get_episode(event)
        elif http_method == 'POST' and '/episodes/' in path and path.endswith('/progress'):
            return handle_post_progress(event)
        elif http_method == 'GET' and '/dashboard/' in path:
            return handle_get_dashboard(event)
        elif http_method == 'GET' and '/constellation' in path:
            return handle_get_constellation(event)
        elif http_method == 'POST' and '/video/generate' in path:
            return handle_generate_video(event)
        elif http_method == 'GET' and '/video/status' in path:
            return handle_video_status(event)

        return respond(404, {"error": f"Route not found: {http_method} {path}"})
    except Exception as e:
        print(f"Error: {str(e)}")
        return respond(500, {"error": "Internal server error", "details": str(e)})
